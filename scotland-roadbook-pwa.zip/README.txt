SCHOTLAND ROADBOOK PWA

Deze map is een complete installable offline webapp.

BELANGRIJK
- Een PWA/service worker werkt via HTTPS (of localhost), niet door index.html direct als file:// te openen.
- Upload de HELE inhoud van deze map naar een HTTPS-host.
- Daarna deel je alleen de URL.

INSTALLATIE
Android (Chrome): open URL -> App installeren / Toevoegen aan startscherm -> open app -> Maak offline beschikbaar.
iPhone (Safari): open URL -> Deel -> Zet op beginscherm -> open app -> Maak offline beschikbaar.
Mac: open URL in Safari/Chrome; de webversie werkt direct.

OFFLINE
Alle routekaarten zijn al in index.html ingebed. De service worker cachet de appbestanden zodat de planning en kaarten zonder internet beschikbaar blijven. Apple/Google Maps-links hebben wel internet nodig.
